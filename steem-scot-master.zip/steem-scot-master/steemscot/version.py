"""THIS FILE IS GENERATED FROM beem SETUP.PY."""
version = '0.2.2'
